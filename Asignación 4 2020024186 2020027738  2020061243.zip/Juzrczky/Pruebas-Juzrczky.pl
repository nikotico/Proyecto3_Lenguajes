% Prueba 1
diff(2^x*x, x, N).

% Prueba 2
diff(log(x)/x^2, x, N).

% Prueba 3
diff( (5*x + 3)^4, x, N).

% Prueba 4
diff( x^7 + 5* x^3 - x^e + 1, x, N).

% Prueba 5
diff( 4*x^3 + 5*y^2 , x, N).

% Prueba 6
diff( 4*x^3 + 5*y^2 , y, N).

% Prueba 7
diff(x^(x*log(cos(x))), x, N).

% Prueba 8
diff( 10*x / (5*x^2 - 3*y) , x, N).

