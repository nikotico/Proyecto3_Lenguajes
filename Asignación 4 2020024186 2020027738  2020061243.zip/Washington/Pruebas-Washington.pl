% Prueba 1
deriv(x^(x*log(cos(x))), x, N).

% Prueba 2
deriv(-5*x + 2, x, N).

% Prueba 3
deriv(x *(x+5), x, N).

% Derivada con dos variables

% Prueba 4
deriv(4*x + 5*y, x, N).

% Prueba 5
deriv(4*x + 5*y, y, N).

% Prueba 6
deriv(2*x^7-3*x^6+3*x^3-4*x^2-7, x, N).

% Prueba 7
deriv(2*x+3*x+3*x+4*x+7, x, N).

% Prueba 8
deriv(x-3/2, x, N).

