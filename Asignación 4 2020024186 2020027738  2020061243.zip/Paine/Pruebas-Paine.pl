% Prueba 1
3*x*u^5 - 2*u^3 + x^2*(u^(1/2)).

% Prueba 2
2*x^7 - 3*x^6 + 3*x^3 - 4*x^2 - 7.

% Prueba 3
(x-3)/2.

% Prueba 4
(x-1) * (x+1)^2.

% Prueba 5
log(x-3)^2.

% Prueba 6
cos(3*x + 3).

% Prueba 7
4*x^3 +3*x^3 + 2*y - 6.

% Prueba 8
4*x^3 +3*x^3 + 2*y - 6.
